
from flask import Flask, render_template, request, redirect, session, flash
import cv2
import os
import random
import numpy as np
import mysql.connector
import pandas as pd
from flask import send_file
from io import BytesIO
from datetime import datetime
from werkzeug.utils import secure_filename

UPLOAD_FOLDER = "static/uploads"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)


app = Flask(__name__)
app.secret_key = "attendance_secret"

# ---------------- MYSQL CONFIG ----------------
DB_CONFIG = {
    "host": "localhost",
    "user": "root",
    "password": "",      # XAMPP default
    "database": "smart_attendance"
}
#------------home-------------------
@app.route("/")
def home():
    return redirect("/login_portal")


# ---------------- DB CONNECTION ----------------
def get_db_connection():
    return mysql.connector.connect(**DB_CONFIG)

# ---------------- DB SETUP ----------------
def init_db():
    conn = get_db_connection()
    cur = conn.cursor()

    cur.execute("""
        CREATE TABLE IF NOT EXISTS students (
            id INT AUTO_INCREMENT PRIMARY KEY,
            roll_no VARCHAR(50) UNIQUE,
            name VARCHAR(100)
        )
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS attendance (
            id INT AUTO_INCREMENT PRIMARY KEY,
            student_id INT,
            name VARCHAR(100),
            date DATE,
            time TIME
        )
    """)

    conn.commit()
    cur.close()
    conn.close()
    print("✅ Database ready")

init_db()

#_______________LIVE CAMERA________________________
camera = cv2.VideoCapture(0)

def gen_frames(student_id):
    detector = cv2.CascadeClassifier(
        cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
    )

    count = 0
    os.makedirs(f"dataset/{student_id}", exist_ok=True)

    while True:
        success, frame = camera.read()
        if not success:
            break

        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = detector.detectMultiScale(gray, 1.3, 5)

        for (x, y, w, h) in faces:
            count += 1
            face = gray[y:y+h, x:x+w]
            cv2.imwrite(f"dataset/{student_id}/{count}.jpg", face)

            cv2.rectangle(frame, (x,y), (x+w,y+h), (0,255,0), 2)

        # send frame to browser
        ret, buffer = cv2.imencode('.jpg', frame)
        frame = buffer.tobytes()

        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')

        if count >= 30:
            break

#----------------------------teacher id------------------------------
import random

def generate_teacher_id(batch_name):
    # Extract letters & numbers from batch (e.g. BCA2023 → BCA23)
    letters = ''.join([c for c in batch_name if c.isalpha()])[:3].upper()
    numbers = ''.join([c for c in batch_name if c.isdigit()])[-2:]

    rand = random.randint(1000, 9999)
    return f"TCH-{letters}{numbers}-{rand}"

#---------------pwecentage_____________
def calculate_attendance_percentage():
    conn = get_db_connection()
    cur = conn.cursor(dictionary=True)

    cur.execute("SELECT COUNT(DISTINCT date) AS total_days FROM attendance")
    total_days = cur.fetchone()["total_days"] or 1

    cur.execute("""
        SELECT roll_no, name, COUNT(*) AS present_days
        FROM attendance
        GROUP BY roll_no, name
    """)

    records = cur.fetchall()
    cur.close()
    conn.close()

    for r in records:
        r["percentage"] = round((r["present_days"] / total_days) * 100, 2)

    return records
#---------------montly report----------------------
def get_monthly_attendance(batch):
    conn = get_db_connection()
    cur = conn.cursor(dictionary=True)

    cur.execute("""
        SELECT DATE_FORMAT(a.date, '%Y-%m') AS month,
               COUNT(*) AS total
        FROM attendance a
        JOIN students s ON a.roll_no = s.roll_no
        WHERE s.batch = %s
        GROUP BY month
        ORDER BY month
    """, (batch,))

    data = cur.fetchall()

    cur.close()
    conn.close()

    return data


#-------------------student list same batch----------------------
def get_students_by_batch(batch):
    conn = get_db_connection()
    cur = conn.cursor(dictionary=True)

    cur.execute("""
        SELECT roll_no, name
        FROM students
        WHERE batch = %s
        ORDER BY roll_no
    """, (batch,))

    students = cur.fetchall()

    cur.close()
    conn.close()

    return students


#---------------------------------------- Admin LOGIN ------------------------------------
@app.route("/admin_login", methods=["GET", "POST"])
def admin_login():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]

        if username == "admin" and password == "admin":
            session["user"] = "admin"
            return redirect("/dashboard")

        flash("Invalid admin credentials", "danger")

    return render_template("login.html")

#------------------------login portal-------------------------------------
@app.route("/login_portal")
def login_portal():
    conn = get_db_connection()
    cur = conn.cursor(dictionary=True)

    # Portal settings
    cur.execute("SELECT * FROM portal_settings WHERE id=1")
    portal = cur.fetchone()

    # News
    cur.execute("SELECT * FROM news ORDER BY created_at DESC")
    news = cur.fetchall()

    cur.close()
    conn.close()

    backgrounds = []
    if portal and portal["background_images"]:
        backgrounds = portal["background_images"].split(",")

    return render_template(
        "login_portal.html",
        university_name=portal["university_name"] if portal else "University Portal",
        logo=portal["logo"] if portal else None,
        backgrounds=backgrounds,
        news=news
    )


#-----------------------------------student login------------------------------
@app.route("/student_login", methods=["GET", "POST"])
def student_login():
    if request.method == "POST":
        roll_no = request.form["roll_no"]
        email = request.form["email"]

        conn = get_db_connection()
        cur = conn.cursor()

        cur.execute("""
            SELECT id, name FROM students
            WHERE roll_no=%s AND email=%s
        """, (roll_no, email))

        student = cur.fetchone()
        cur.close()
        conn.close()

        if student:
            session["student_id"] = student[0]
            session["student_name"] = student[1]
            return redirect("/student_dashboard")

        flash("Invalid student credentials", "danger")

    return render_template("student_login.html")
#------------------------------------teacher login---------------------------------
@app.route("/teacher_login", methods=["GET", "POST"])
def teacher_login():
    if request.method == "POST":
        teacher_id = request.form["teacher_id"]
        password = request.form["password"]

        conn = get_db_connection()
        cur = conn.cursor(dictionary=True)

        cur.execute("""
            SELECT teacher_id, name, course, batch
            FROM teachers
            WHERE teacher_id=%s AND password=%s
        """, (teacher_id, password))

        teacher = cur.fetchone()

        cur.close()
        conn.close()

        if teacher:
            session["teacher_id"] = teacher["teacher_id"]
            session["teacher_name"] = teacher["name"]
            session["course"] = teacher["course"]
            session["batch"] = teacher["batch"]

            return redirect("/teacher_dashboard")
        else:
            return render_template("teacher_login.html", error="Invalid credentials")

    return render_template("teacher_login.html")

#---------------------export report_______________________

@app.route("/export_attendance")
def export_attendance():
    if "teacher_id" not in session:
        return redirect("/teacher_login")

    date = request.args.get("date")

    conn = get_db_connection()
    cur = conn.cursor(dictionary=True)

    if date:
        cur.execute("""
    SELECT a.roll_no, a.name, a.date, a.time
    FROM attendance a
    JOIN students s ON a.roll_no = s.roll_no
    WHERE a.date=%s
      AND s.course=%s
      AND s.batch=%s
""", (date, session["course"], session["batch"]))

    else:
        cur.execute("SELECT roll_no, name, date, time FROM attendance")

    data = cur.fetchall()
    cur.close()
    conn.close()

    df = pd.DataFrame(data)

    output = BytesIO()
    df.to_excel(output, index=False)
    output.seek(0)

    return send_file(
        output,
        download_name="attendance.xlsx",
        as_attachment=True
    )

# ---------------- DASHBOARD ----------------
@app.route("/dashboard")
def dashboard():
    if "user" not in session:
        return redirect("/")
    return render_template("dashboard.html")
#--------------------------student dashboard__________________________________
@app.route("/student_dashboard")
def student_dashboard():
    if "student_id" not in session:
        return redirect("/student_login")

    conn = get_db_connection()
    cur = conn.cursor()

    cur.execute("""
        SELECT date, time FROM attendance
        WHERE student_id=%s
        ORDER BY date DESC
    """, (session["student_id"],))

    records = cur.fetchall()

    # Attendance percentage
    cur.execute("SELECT COUNT(DISTINCT date) FROM attendance")
    total_days = cur.fetchone()[0] or 0

    cur.execute("""
        SELECT COUNT(*) FROM attendance
        WHERE student_id=%s
    """, (session["student_id"],))
    present = cur.fetchone()[0]

    percentage = round((present / total_days) * 100, 2) if total_days > 0 else 0

    cur.close()
    conn.close()

    return render_template(
        "student_dashboard.html",
        records=records,
        percentage=percentage
    )
#--------------student profile________________
@app.route("/student_profile/<roll_no>")
def student_profile(roll_no):
    if "teacher_id" not in session:
        return redirect("/teacher_login")

    conn = get_db_connection()
    cur = conn.cursor(dictionary=True)

    cur.execute("SELECT * FROM students WHERE roll_no=%s", (roll_no,))
    student = cur.fetchone()

    cur.execute("""
        SELECT date, time FROM attendance
        WHERE roll_no=%s
        ORDER BY date DESC
    """, (roll_no,))
    attendance = cur.fetchall()

    cur.close()
    conn.close()

    return render_template(
        "student_profile.html",
        student=student,
        attendance=attendance
    )



#------------------------------------teacher dashboard---------------------------------------
@app.route("/teacher_dashboard", methods=["GET", "POST"])
def teacher_dashboard():
    if "teacher_id" not in session:
        return redirect("/teacher_login")

    selected_date = None
    attendance = []

    # ✅ Always create connection & cursor
    conn = get_db_connection()
    cur = conn.cursor(dictionary=True)

    # Date-wise attendance (POST)
    if request.method == "POST":
        selected_date = request.form["date"]

        cur.execute("""
    SELECT a.roll_no, a.name, a.date, a.time
    FROM attendance a
    JOIN students s ON a.roll_no = s.roll_no
    WHERE a.date = %s
      AND s.batch = %s
    ORDER BY a.time
""", (selected_date, session["batch"]))


        attendance = cur.fetchall()

    # Attendance percentage
    percentages = calculate_attendance_percentage()

    # Monthly analysis
    monthly_data = get_monthly_attendance(session["batch"])
    students = get_students_by_batch(session["batch"])


    # Students list (same batch)
    students = get_students_by_batch(
        session["batch"]
    )

    cur.close()
    conn.close()

    return render_template(
        "teacher_dashboard.html",
        teacher_name=session["teacher_name"],
        course=session["course"],
        batch=session["batch"],
        attendance=attendance,
        selected_date=selected_date,
        percentages=percentages,
        monthly_data=monthly_data,
        students=students
    )


#----------------------------add teacher-----------------------
@app.route("/add_teacher", methods=["GET", "POST"])
def add_teacher():
    if "user" not in session:
        return redirect("/admin_login")

    conn = get_db_connection()
    cur = conn.cursor(dictionary=True)

    # Fetch courses
    cur.execute("SELECT course_name FROM courses ORDER BY course_name")
    courses = cur.fetchall()

    # Fetch batches
    cur.execute("SELECT batch_name FROM batches ORDER BY batch_name")
    batches = cur.fetchall()

    if request.method == "POST":
        name = request.form["name"]
        course = request.form["course"]
        batch = request.form["batch"]
        password = request.form["password"]

        teacher_id = generate_teacher_id(batch)

        cur.execute("""
            INSERT INTO teachers (teacher_id, name, course, batch, password)
            VALUES (%s, %s, %s, %s, %s)
        """, (teacher_id, name, course, batch, password))

        conn.commit()

        # ✅ STORE FOR POPUP
        session["teacher_created"] = True
        session["new_teacher_id"] = teacher_id

        cur.close()
        conn.close()

        return redirect("/add_teacher")

    cur.close()
    conn.close()

    return render_template(
        "add_teacher.html",
        courses=courses,
        batches=batches
    )
#====================teacher logout================
@app.route("/teacher_logout")
def teacher_logout():
    session.clear()
    return redirect("/teacher_login")

#==============POP==============
@app.route("/clear_teacher_popup")
def clear_teacher_popup():
    session.pop("teacher_created", None)
    session.pop("new_teacher_id", None)
    return "", 204

@app.route("/clear_student_popup")
def clear_student_popup():
    session.pop("student_registered", None)
    session.pop("registered_student_name", None)
    return "", 204


# ---------------- FACE DUPLICATE CHECK ----------------
def check_face_duplicate(face_img):
    if not os.path.exists("trainer/trainer.yml"):
        return None

    recognizer = cv2.face.LBPHFaceRecognizer_create()
    recognizer.read("trainer/trainer.yml")

    student_id, conf = recognizer.predict(face_img)
    if conf < 60:
        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute("SELECT name FROM students WHERE id=%s", (student_id,))
        row = cur.fetchone()
        cur.close()
        conn.close()
        if row:
            return row[0]
    return None

# ---------------- FACE CAPTURE ----------------
def capture_faces(student_id):
    cam = cv2.VideoCapture(0, cv2.CAP_DSHOW)
    detector = cv2.CascadeClassifier(
        cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
    )

    os.makedirs(f"dataset/{student_id}", exist_ok=True)
    count = 0

    while count < 30:
        ret, img = cam.read()
        if not ret:
            continue

        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        faces = detector.detectMultiScale(gray, 1.3, 5)

        for (x, y, w, h) in faces:
            count += 1
            cv2.imwrite(f"dataset/{student_id}/{count}.jpg", gray[y:y+h, x:x+w])
            cv2.rectangle(img, (x,y), (x+w,y+h), (0,255,0), 2)

        cv2.imshow("Register Face", img)
        if cv2.waitKey(1) == 27:
            break

    cam.release()
    cv2.destroyAllWindows()

# ---------------- TRAIN MODEL ----------------
def train_model():
    recognizer = cv2.face.LBPHFaceRecognizer_create()
    faces, ids = [], []

    if not os.path.exists("dataset"):
        return

    for folder in os.listdir("dataset"):
        for img in os.listdir(f"dataset/{folder}"):
            image = cv2.imread(f"dataset/{folder}/{img}", 0)
            if image is None:
                continue
            faces.append(image)
            ids.append(int(folder))

    if len(faces) == 0:
        return

    recognizer.train(faces, np.array(ids))
    os.makedirs("trainer", exist_ok=True)
    recognizer.save("trainer/trainer.yml")

# ---------------- REGISTER STUDENT ----------------
@app.route("/register", methods=["GET", "POST"])
def register():
    if "user" not in session:
        return redirect("/admin_login")

    conn = get_db_connection()
    cur = conn.cursor(dictionary=True)

    # 🔹 FETCH COURSES & BATCHES FOR DROPDOWNS
    cur.execute("SELECT course_name FROM courses ORDER BY course_name")
    courses = cur.fetchall()

    cur.execute("SELECT batch_name FROM batches ORDER BY batch_name")
    batches = cur.fetchall()

    if request.method == "POST":
        roll_no = request.form["roll_no"]
        name = request.form["name"]
        course = request.form["course"]
        batch = request.form["batch"]

        # ✅ SAVE STUDENT WITH COURSE & BATCH
        cur.execute("""
            INSERT INTO students (roll_no, name, course, batch)
            VALUES (%s, %s, %s, %s)
        """, (roll_no, name, course, batch))

        conn.commit()

        # Store student id for face capture
        student_id = cur.lastrowid
        session["face_student_id"] = student_id
        session["face_student_name"] = name

        cur.close()
        conn.close()

        return redirect("/register")

    cur.close()
    conn.close()

    return render_template(
        "register.html",
        courses=courses,
        batches=batches
    )





#------------------register face------------------------
@app.route("/register_face")
def register_face():
    if "face_student_id" not in session:
        return redirect("/register")

    return render_template("register_face.html")
#----------------faecdone-------------------------
@app.route("/face_done")
def face_done():
    train_model()

    session["student_registered"] = True
    session["registered_student_name"] = session.get("face_student_name")

    session.pop("face_student_id", None)
    session.pop("face_student_name", None)

    return redirect("/register")


# ---------------- ATTENDANCE ----------------
@app.route("/attendance")
def attendance():
    if "user" not in session:
        return redirect("/")

    if not os.path.exists("trainer/trainer.yml"):
        return "Model not trained"

    recognizer = cv2.face.LBPHFaceRecognizer_create()
    recognizer.read("trainer/trainer.yml")

    cam = cv2.VideoCapture(0, cv2.CAP_DSHOW)
    detector = cv2.CascadeClassifier(
        cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
    )

    conn = get_db_connection()
    cur = conn.cursor()

    while True:
        ret, img = cam.read()
        if not ret:
            continue

        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        faces = detector.detectMultiScale(gray, 1.3, 5)

        for (x,y,w,h) in faces:
            student_id, conf = recognizer.predict(gray[y:y+h, x:x+w])

            if conf < 70:
                cur.execute("SELECT name FROM students WHERE id=%s", (student_id,))
                row = cur.fetchone()
                if not row:
                    continue

                name = row[0]
                today = datetime.now().date()

                cur.execute(
                    "SELECT id FROM attendance WHERE student_id=%s AND date=%s",
                    (student_id, today)
                )

                if cur.fetchone():
                    cam.release()
                    cv2.destroyAllWindows()
                    cur.close()
                    conn.close()
                    return f"Attendance already marked for {name}"

                cur.execute("""
    INSERT INTO attendance (student_id, roll_no, name, date, time)
    VALUES (%s, %s, %s, %s, %s)
""", (id, roll_no, name, date, time))

                conn.commit()

                cam.release()
                cv2.destroyAllWindows()
                cur.close()
                conn.close()
                return render_template("attendance.html", name=name)

        cv2.imshow("Attendance", img)
        if cv2.waitKey(1) == 27:
            break

    cam.release()
    cv2.destroyAllWindows()
    cur.close()
    conn.close()
    return redirect("/dashboard")
#=====================Attendance table++++++++++++++++========================
@app.route("/attendance_table")
def attendance_table():
    if "user" not in session:
        return redirect("/")

    conn = get_db_connection()
    cur = conn.cursor()

    # Total distinct attendance days
    cur.execute("SELECT COUNT(DISTINCT date) FROM attendance")
    total_days = cur.fetchone()[0] or 0

    # Attendance records with roll number
    cur.execute("""
        SELECT s.roll_no, s.name, a.student_id, a.date, a.time
        FROM attendance a
        JOIN students s ON a.student_id = s.id
        ORDER BY a.date DESC, a.time DESC
    """)
    records = cur.fetchall()

    # Calculate attendance count per student
    cur.execute("""
        SELECT student_id, COUNT(*) 
        FROM attendance
        GROUP BY student_id
    """)
    counts = cur.fetchall()

    cur.close()
    conn.close()

    # Convert counts to dictionary
    attendance_count = {sid: count for sid, count in counts}

    # Final data with percentage
    final_records = []
    for row in records:
        roll_no, name, student_id, date, time = row
        present_days = attendance_count.get(student_id, 0)
        percentage = round((present_days / total_days) * 100, 2) if total_days > 0 else 0
        final_records.append((roll_no, name, date, time, percentage))

    return render_template(
        "attendance_table.html",
        records=final_records
    )
#-----------------------------admin newss---------------------------------
@app.route("/admin_news", methods=["GET", "POST"])
def admin_news():
    if "user" not in session:
        return redirect("/admin_login")

    conn = get_db_connection()
    cur = conn.cursor(dictionary=True)

    if request.method == "POST":
        form_type = request.form.get("form_type")

        # =========================
        # PORTAL APPEARANCE SETTINGS
        # =========================
        if form_type == "portal_settings":
            university_name = request.form.get("university_name")
            logo = request.files.get("logo")
            backgrounds = request.files.getlist("backgrounds")

            # Existing logo fallback
            cur.execute("SELECT * FROM portal_settings WHERE id=1")
            portal = cur.fetchone()

            logo_name = portal["logo"] if portal else None

            if logo and logo.filename:
                logo_name = secure_filename(logo.filename)
                logo.save(os.path.join(UPLOAD_FOLDER, logo_name))

            bg_files = []
            for bg in backgrounds:
                if bg and bg.filename:
                    fname = secure_filename(bg.filename)
                    bg.save(os.path.join(UPLOAD_FOLDER, fname))
                    bg_files.append(fname)

            bg_string = ",".join(bg_files) if bg_files else portal["background_images"]

            cur.execute("""
                UPDATE portal_settings
                SET university_name=%s,
                    logo=%s,
                    background_images=%s
                WHERE id=1
            """, (university_name, logo_name, bg_string))

            conn.commit()

        # =========================
        # PORTAL ANNOUNCEMENTS
        # =========================
        elif form_type == "portal_announcement":
            title = request.form.get("title")
            description = request.form.get("description")
            image = request.files.get("image")

            filename = None
            if image and image.filename:
                filename = secure_filename(image.filename)
                image.save(os.path.join(UPLOAD_FOLDER, filename))

            cur.execute("""
                INSERT INTO news (title, description, image)
                VALUES (%s, %s, %s)
            """, (title, description, filename))

            conn.commit()

    # =========================
    # FETCH DATA FOR PAGE
    # =========================
    cur.execute("SELECT * FROM news ORDER BY created_at DESC")
    news = cur.fetchall()

    cur.execute("SELECT * FROM portal_settings WHERE id=1")
    portal = cur.fetchone()

    cur.close()
    conn.close()

    return render_template(
        "admin_news.html",
        news=news,
        portal=portal
    )

#------------------portal-------------------------
@app.route("/portal_settings", methods=["POST"])
def portal_settings():
    if "user" not in session:
        return redirect("/admin_login")

    name = request.form["university_name"]
    logo = request.files.get("logo")
    backgrounds = request.files.getlist("backgrounds")

    conn = get_db_connection()
    cur = conn.cursor(dictionary=True)

    # Handle logo
    if logo and logo.filename:
        logo_name = secure_filename(logo.filename)
        logo.save(os.path.join(UPLOAD_FOLDER, logo_name))
    else:
        cur.execute("SELECT logo FROM portal_settings WHERE id=1")
        logo_name = cur.fetchone()["logo"]

    # Handle background images
    bg_files = []
    for bg in backgrounds:
        if bg.filename:
            fname = secure_filename(bg.filename)
            bg.save(os.path.join(UPLOAD_FOLDER, fname))
            bg_files.append(fname)

    bg_string = ",".join(bg_files) if bg_files else None

    cur.execute("""
        UPDATE portal_settings
        SET university_name=%s, logo=%s,
            background_images=COALESCE(%s, background_images)
        WHERE id=1
    """, (name, logo_name, bg_string))

    conn.commit()
    cur.close()
    conn.close()

    return redirect("/admin_news")
#--------------------managebatches-------------------
@app.route("/manage_batches", methods=["GET", "POST"])
def manage_batches():
    if "user" not in session:
        return redirect("/admin_login")

    conn = get_db_connection()
    cur = conn.cursor(dictionary=True)

    form = request.form.get("form_type")

    # Add course
    if form == "course":
        name = request.form.get("course_name")
        if name:
            cur.execute("INSERT IGNORE INTO courses (course_name) VALUES (%s)", (name,))
            conn.commit()

    # Add batch
    if form == "batch":
        name = request.form.get("batch_name")
        if name:
            cur.execute("INSERT IGNORE INTO batches (batch_name) VALUES (%s)", (name,))
            conn.commit()

    # Add academic year
    if form == "year":
        course_id = request.form.get("course_id")
        batch_id = request.form.get("batch_id")
        year = request.form.get("year")
        if course_id and batch_id and year:
            cur.execute("""
                INSERT INTO academic_years (course_id, batch_id, year)
                VALUES (%s, %s, %s)
            """, (course_id, batch_id, year))
            conn.commit()

    # Fetch data
    cur.execute("SELECT * FROM courses")
    courses = cur.fetchall()

    cur.execute("SELECT * FROM batches")
    batches = cur.fetchall()

    cur.execute("""
        SELECT academic_years.id, courses.course_name, batches.batch_name, academic_years.year
        FROM academic_years
        JOIN courses ON academic_years.course_id = courses.id
        JOIN batches ON academic_years.batch_id = batches.id
        ORDER BY academic_years.year DESC
    """)
    years = cur.fetchall()

    cur.close()
    conn.close()

    return render_template(
        "manage_batches.html",
        courses=courses,
        batches=batches,
        years=years
    )
#==================delete batchess-----------------
@app.route("/delete_course/<int:id>")
def delete_course(id):
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("DELETE FROM courses WHERE id=%s", (id,))
    conn.commit()
    cur.close()
    conn.close()
    return redirect("/manage_batches")
#----------------------------------------------------------
@app.route("/delete_batch/<int:id>")
def delete_batch(id):
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("DELETE FROM batches WHERE id=%s", (id,))
    conn.commit()
    cur.close()
    conn.close()
    return redirect("/manage_batches")

#---------------VIDEO________________
@app.route('/video_feed')
def video_feed():
    if "face_student_id" not in session:
        return "No student"

    return Response(
        gen_frames(session["face_student_id"]),
        mimetype='multipart/x-mixed-replace; boundary=frame'
    )




# ---------------- LOGOUT ----------------
@app.route("/logout")
def logout():
    session.clear()
    return redirect("/")

# ---------------- RUN ----------------
if __name__ == "__main__":
    app.run(debug=True)
